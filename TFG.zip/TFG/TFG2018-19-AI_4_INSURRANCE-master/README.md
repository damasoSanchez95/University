# TFG2018-19-AI4SEGUROS
 Desarrollo de un sistema de predicción de riesgo en seguros de automóviles mediante Redes Neuronales y Programación Genética
