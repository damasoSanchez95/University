#!/usr/bin/env python
# coding: utf-8

# Desglose en funciones de los pasos necesarios para limpiar los datos

# In[1]:


import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler


# In[2]:


def traspasoDatos(ruta):
    
    data = pd.read_excel(ruta)
    
    return data


# In[3]:


def getDropable(data, listaColumnas):
    
    dropable = data.columns
    
    dropable = dropable.drop('Tipo siniestro')
    
    for column in dropable:
        
        if column in listaColumnas:
            dropable = dropable.drop(column)
    
    return dropable

def numerize(data):
    
    clean_data = data.fillna(0)
    
    clean_data['ClaseVehiculo'] = clean_data['ClaseVehiculo'].str.upper()    
    clean_data['ClaseVehiculo'] = clean_data['ClaseVehiculo'].fillna('NAN')
    #mapeo de tipo de pago y modalidad seleccionada
    clean_data['TipoCarnet'] = clean_data['TipoCarnet'].map({'Li':0,'AM':1, 'A1':2, 'A2':3, 'A':4, 'B1':5, 'B':6, 'C1':7, 'C':8, 'D1':9, 'D':10, 'BE':11, 'C1E':12, 'CE':13, 'D1E':14, 'DE':15}).astype(int)
    clean_data['ClaseVehiculo'] = clean_data['ClaseVehiculo'].map({'23':0,'3A':1, '3B':2, '3C':3, '3D':4, '3E':5, '3H':6, '3J':7, '3K':8, '3N':9, '3P':10, '3Q':11, '3R':12, '3S':13, '3T':14, 'C05':15, 'C06':16, 'C07':17, 'C08':18, 'C09':19, 'C10':20, 'C11':21, 'C12':22, 'C13':23, 'C14':24, 'M01':25, 'M02':26, 'M05':27, 'M06':28, 'M07':29, 'M09':30, 'M10':31, 'M11':32, 'M12':33, 'M13':34, 'M14':35, 'M15':36, 'M16':37, 'M17':38, 'M18':39, 'M19':40, 'M20':41, 'M21':42, 'M22':43, 'M23':44, 'M24':45, 'M25':46, 'M26':47, 'M27':48, 'M28':49, 'M29':50, 'M30':51, 'M31':52, 'M32':53, 'M33':54, 'M34':55, 'M35':56, 'M36':57, 'M37':58, 'MM1':59, 'MM2':60, 'MM3':61, 'XC1':62,'NAN':63}).astype(int)
    clean_data['Tipo de Pago'] = clean_data['Tipo de Pago'].map({'PagoAnual':1, 'PagoSemestral':2, 'PagoTrimestral':3}).astype(int)
    clean_data['ModalidadSeleccionada'] = clean_data['ModalidadSeleccionada'].map({'ModalidadBasica':1, 'ModalidadAmpliada':2, 'TodoRiesgoConFranquicia':3}).astype(int)
    
    #mapeo del tipo de siniestro
    name = clean_data['Tipo siniestro'] 
    clean_data.loc[name == 'CULPA', 'Tipo siniestro'] = 1
    clean_data.loc[name == 'RECLAMACIÓN', 'Tipo siniestro'] = 2
    
    #Sacamos los años de las siguientes columnas
    clean_data['FechaCarnet'] = clean_data.FechaCarnet.dt.year.astype(int) 
    clean_data['FechaNacimiento']= clean_data.FechaNacimiento.dt.year.astype(int)  
    clean_data['FechaMatriculacion']= clean_data.FechaMatriculacion.dt.year.astype(int)  
    
    #Hasheamos columnas con un numero distinto de elementos desconocido o muy alto como para mapearlo
    clean_data['Email'] = mapMail(clean_data)
    clean_data['Marca'] = mapMarca(clean_data)
    clean_data['Modelo'] = mapModel(clean_data)
    
    return clean_data


# In[4]:


def limpiezaDatos(data,listaColumnas):

    clean_data = numerize(data)
    
    dropable = getDropable(clean_data,listaColumnas)
        
    clean_data = clean_data.drop(dropable, axis = 1)
           
    return clean_data


# In[5]:


def mapMarcas(nombre):
        
        if(nombre == 'YAMAHA'):
            result = 1
            
        elif(nombre == 'APRILIA'):
            result = 2
        
        elif(nombre == 'KAWASAKI'):
            result = 3
            
        elif(nombre == 'PIAGGIO-VESPA'):
            result = 4
        
        elif(nombre == 'SUZUKI'):
            result = 5
        
        elif(nombre == 'HONDA'):
            result = 6
            
        elif(nombre == 'RIEJU'):
            result = 7
        
        elif(nombre == 'BMW'):
            result = 8
            
        else:
            result = 9
            
        return result


# In[6]:


def mapMarca(data):
    
    data['Marca'] = data['Marca'].str.upper()
    
    d = pd.DataFrame(data['Marca'])
    data['Marca'] = d.applymap(mapMarcas)
    
    return data['Marca']


# In[7]:


def mapMails(nombre):

    if(nombre == 'hotmail.com' or nombre == 'hotmail.es'):
        result = 1

    elif(nombre == 'gmail.com' or nombre == 'gmail.es'):
        result = 2

    elif(nombre == 'yahoo.com' or nombre == 'yahoo.es'):
        result = 3

    else:
        result = 4
        
    return result


# In[8]:


def mapMail(data):
    
    data['Email'] = data['Email'].str.lower()
    
    d = pd.DataFrame(data['Email'])
    data['Email'] = d.applymap(mapMails)
    
    return data['Email']


# In[9]:


def mapModelos(nombre):

    if(nombre == 'CBR 600'):
        result = 1

    elif(nombre == 'Z 750'):
        result = 2

    elif(nombre == 'FZ6'):
        result = 3
        
    elif(nombre == 'LT Z'):
        result = 4

    elif(nombre == 'GSXR 600'):
        result = 5
        
    elif(nombre == 'CB 600') :
        result = 6

    elif(nombre == 'GSR'):
        result = 7

    elif(nombre == 'XP 500'):
        result = 8

    elif(nombre == 'ER-6'):
        result = 9
        
    elif(nombre == 'VESPA 125'):
        result = 10

    elif(nombre == 'VESPA 125'):
        result = 11
         
    elif(nombre == 'YZF 600'):
        result = 12

    elif(nombre ==  'JOG 50'):
        result = 13
        
    elif(nombre == 'CBR 1000'):
        result = 14

    elif(nombre == 'X-MAX'):
        result = 15 

    elif(nombre == 'VESPA 200'):
        result = 16
        
    elif(nombre == 'ZX-6 R'):
        result = 17

    elif(nombre == 'VESPINO'):
        result = 18
         
    elif(nombre == 'GS 500'):
        result = 19
        
    elif(nombre == 'YZF R6'):
        result = 20

    elif(nombre == 'SR 250'):
        result = 21
         
    elif(nombre == 'ZIP 50'):
        result = 22
        
    elif(nombre == 'XCITING'):
        result = 23

    elif(nombre == 'ZZR 600'):
        result = 24
         
    elif(nombre == 'SUPER DINK'):
        result = 25       
         
    elif(nombre == 'RRT 50'):
        result = 26       
         
    elif(nombre == 'GSF 650'):
        result = 27       
         
    elif(nombre == 'CBR 125'):
        result = 28       
         
    elif(nombre == 'SCOOPY 300I SH'):
        result = 29       
         
    elif(nombre == 'GSXR 750'):
        result = 30      
         
    elif(nombre == 'RS 125'):
        result = 31               
        
    elif(nombre == 'SCOOPY 125I SH'):
        result = 32
         
    elif(nombre == 'BEVERLY'):
        result = 33     
         
    elif(nombre == 'TZR 50'):
        result = 34     
         
    elif(nombre == 'CB 500'):
        result = 35     
         
    elif(nombre == 'LIBERTY 50'):
        result = 36     
         
    elif(nombre == 'CBR 900'):
        result = 37     
         
    elif(nombre == 'YZF 125'):
        result = 38    
         
    elif(nombre == 'MRX 50'):
        result = 39
         
    elif(nombre == 'SV 650'):
        result = 40       
         
    else:
        result = 0

    return result


# In[10]:


def mapModel(data):
    
    data['Modelo'] = data['Modelo'].str.upper()
    
    d = pd.DataFrame(data['Modelo'])
    data['Modelo'] = d.applymap(mapModelos)
    
    return data['Modelo']


# In[11]:


def cleanSolicitar(data):
    
    data['Email'] = mapMail(data)
    data['TipoCarnet'] = data['TipoCarnet'].map({'Li':0,'AM':1, 'A1':2, 'A2':3, 'A':4, 'B1':5, 'B':6, 'C1':7, 'C':8, 'D1':9, 'D':10, 'BE':11, 'C1E':12, 'CE':13, 'D1E':14, 'DE':15}).astype(int)
    data['ConductorUnico'] = data['ConductorUnico'].map({'SI':0,'NO':1}).astype(int)
    data['Marca'] = mapMarca(data)
    data['Modelo'] = mapModel(data)
    data['VehiculoHistorico'] = data['VehiculoHistorico'].map({'SI':0,'NO':1}).astype(int)
    data['Tipo de Pago'] = data['Tipo de Pago'].map({'Anual':1, 'Semestral':2, 'Trimestral':3}).astype(int)
    data['ModalidadSeleccionada'] = data['ModalidadSeleccionada'].map({'Basica':1, 'Ampliada':2, 'Todo Riesgo':3}).astype(int)
    
    data['ClaseVehiculo'] = data['ClaseVehiculo'].str.upper()    
    data['ClaseVehiculo'] = data['ClaseVehiculo'].fillna('NAN')
    data['ClaseVehiculo'] = data['ClaseVehiculo'].map({'23':0,'3A':1, '3B':2, '3C':3, '3D':4, '3E':5, '3H':6, '3J':7, '3K':8, '3N':9, '3P':10, '3Q':11, '3R':12, '3S':13, '3T':14, 'C05':15, 'C06':16, 'C07':17, 'C08':18, 'C09':19, 'C10':20, 'C11':21, 'C12':22, 'C13':23, 'C14':24, 'M01':25, 'M02':26, 'M05':27, 'M06':28, 'M07':29, 'M09':30, 'M10':31, 'M11':32, 'M12':33, 'M13':34, 'M14':35, 'M15':36, 'M16':37, 'M17':38, 'M18':39, 'M19':40, 'M20':41, 'M21':42, 'M22':43, 'M23':44, 'M24':45, 'M25':46, 'M26':47, 'M27':48, 'M28':49, 'M29':50, 'M30':51, 'M31':52, 'M32':53, 'M33':54, 'M34':55, 'M35':56, 'M36':57, 'M37':58, 'MM1':59, 'MM2':60, 'MM3':61, 'XC1':62,'NAN':63}).astype(int)
    
    clean_array = np.array(data)
    
    scaler = StandardScaler()  
    scaler.fit(clean_array)
    
    result = scaler.transform(clean_array)
    
    return result

