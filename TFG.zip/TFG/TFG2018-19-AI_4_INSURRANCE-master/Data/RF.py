#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler


# In[2]:


def accuracy(clean_data):
    
    X_train, X_test, y_train, y_test = split(clean_data)
    
    scaler = StandardScaler()  
    scaler.fit(X_train)

    X_train = scaler.transform(X_train)  
    X_test = scaler.transform(X_test)  
    
    clf = fit(X_train,y_train)
    
    scores = cross_val_score(clf, X_test, y_test, cv=5)
    
    return round(scores.mean()*100, 2)


# In[3]:


def fit(X_train,y_train):
    
    clf = RandomForestClassifier()
    clf.fit(X_train,y_train)
    
    return clf   


# In[4]:


def split(clean_data):

    X_train, X_test, y_train, y_test = train_test_split(clean_data.drop(clean_data.columns[len(clean_data.columns)-1],1), clean_data[clean_data.columns[len(clean_data.columns)-1]], 
                                            test_size=0.3, 
                                            random_state=0)

    return X_train, X_test, y_train, y_test


# In[5]:


def crearModelo(clean_data):
    
    X_train, X_test, y_train, y_test = split(clean_data)
    
    scaler = StandardScaler()  
    scaler.fit(X_train)

    X_train = scaler.transform(X_train)  
    X_test = scaler.transform(X_test)
    
    clf = fit(X_train,y_train)
    
    return clf

