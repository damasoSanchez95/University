#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler


# In[2]:


def accuracy(clean_data,num_nodos,num_capas):
    

    X_train, X_test, y_train, y_test = split(clean_data)
    
    scaler = StandardScaler()  
    scaler.fit(X_train)

    X_train = scaler.transform(X_train)  
    X_test = scaler.transform(X_test)
    
    tupla = capasRed(num_nodos,int(num_capas))
    
    clf = fit(X_train,y_train,tupla)
    
    scores = cross_val_score(clf, X_test, y_test, cv=5)

    return round(scores.mean()*100, 2)


# In[3]:


def split(clean_data):

    X_train, X_test, y_train, y_test = train_test_split(clean_data.drop(clean_data.columns[len(clean_data.columns)-1],1), clean_data[clean_data.columns[len(clean_data.columns)-1]], 
                                            test_size=0.3, 
                                            random_state=0)

    return X_train, X_test, y_train, y_test
        


# In[4]:


def fit(X_train,y_train,tupla):
    
    clf = MLPClassifier(hidden_layer_sizes = tupla)
    clf.fit(X_train,y_train)
    
    return clf   


# In[5]:


def crearModelo(clean_data,num_nodos,num_capas):
    
    X_train, X_test, y_train, y_test = split(clean_data)
    
    scaler = StandardScaler()  
    scaler.fit(X_train)

    X_train = scaler.transform(X_train)  
    X_test = scaler.transform(X_test)
    
    tupla = capasRed(num_nodos,int(num_capas))
    
    clf = fit(X_train,y_train,tupla)
    
    return clf


# In[6]:


def capasRed(nodos,capas):
    
    tupla = "("

    for i in range(0,capas):
        tupla += nodos + ","


    tupla = tupla[:-1]

    tupla += ")"

    return eval(tupla)

