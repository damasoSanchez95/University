package servidor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class User {

	private Scanner scanner;
	private Client client;
	
	public User(int idIn, int portIn, ArrayList<String> fileNamesIn) throws Exception{
		client = new Client(idIn, portIn, fileNamesIn);
		scanner = new Scanner(System.in);
	}
	
	public void listen() throws Exception{
		try {
			boolean exit = false;
			String in[], out = "";
			while(!exit){
				in = scanner.nextLine().split(" ");
				switch(in[0]){
				case "login": 
					out = client.logInRequest();
					break;
				case "list": 
					out = client.listRequest();
					break;
				case "download": 
					out = client.download(Integer.parseInt(in[1]), in[2]);
					break;
				case "logout":
					out = client.logOutRequest();
					exit = true;
					break;
				default:
					out = "Error! Command not recognize";
				}
				System.out.println(out);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws Exception {
		new User(1, 5001, new ArrayList<>(Arrays.asList("kk.txt"))).listen();
	}

}
