package servidor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class Client {
	
	private ServerSocket listenerSocket;
	private int id;
	private int port;
	private ArrayList<String> fileNames;
	private ConcurrentHashMap<String, List<Integer>> files;
	
	public Client(int idIn, int portIn, ArrayList<String> fileNamesIn) throws Exception{
		id = idIn;
		port = portIn;
		fileNames = fileNamesIn;
		listenerSocket = new ServerSocket(port);
		listen();
	}

	
	public String logInRequest() throws Exception{
		String out;
		Socket serverSocket = new Socket(InetAddress.getByName("localhost"), Server.PORT);
		ObjectOutputStream outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
		ObjectInputStream inFromServer = new ObjectInputStream(serverSocket.getInputStream());
		outToServer.writeObject("Login");
		outToServer.writeInt(id);
		outToServer.writeInt(port);
		outToServer.writeObject(fileNames);
		out = (String) inFromServer.readObject();
		outToServer.close();
		inFromServer.close();
		serverSocket.close();
		return out;
	}
	
	@SuppressWarnings("unchecked")
	public String listRequest() throws Exception {
		Socket serverSocket = new Socket(InetAddress.getByName("localhost"), Server.PORT);
		ObjectOutputStream outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
		ObjectInputStream inFromServer = new ObjectInputStream(serverSocket.getInputStream());
		outToServer.writeObject("List");
		files = (ConcurrentHashMap<String, List<Integer>>) inFromServer.readObject();
		outToServer.writeObject("ACK: List received");
		outToServer.close();
		inFromServer.close();
		serverSocket.close();
		return files.toString();
	}
	
	public String download(int targetClientId, String fileName) throws Exception{
		Socket serverSocket = new Socket(InetAddress.getByName("localhost"), Server.PORT);
		ObjectOutputStream outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
		ObjectInputStream inFromServer = new ObjectInputStream(serverSocket.getInputStream());
		outToServer.writeObject("Download");
		outToServer.writeInt(id);
		outToServer.writeObject(fileName);
		outToServer.writeInt(targetClientId);
		outToServer.close();
		inFromServer.close();
		serverSocket.close();
		return "";
	}
	
	public String logOutRequest() throws Exception {
		Socket serverSocket = new Socket(InetAddress.getByName("localhost"), Server.PORT);
		ObjectOutputStream outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
		outToServer.writeObject("Logout");
		outToServer.close();
		serverSocket.close();
		return "";
	}
	
	private void listen() {
		new Thread(new Runnable(){
			@Override
			public void run() {
				while (true){
					Socket socket;
					try {
						socket = listenerSocket.accept();
						new PeerDeamon(socket).start();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			
		}).start();
	}
	
	private void downloadRequest(ObjectInputStream inFromServer) throws Exception {
		int myId = inFromServer.readInt();
		String fileName = (String) inFromServer.readObject();
		int idClientRequesting = inFromServer.readInt();
		Socket serverSocket = new Socket(InetAddress.getByName("localhost"), Server.PORT);
		ObjectOutputStream outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
		outToServer.writeObject("DownloadConfirmation");
		outToServer.writeInt(myId);
		outToServer.writeObject(fileName);
		outToServer.writeInt(idClientRequesting);
		outToServer.close();
		serverSocket.close();
	}
	
	@SuppressWarnings("unused")
	private void downloadConfirmation(ObjectInputStream inFromServer) throws Exception {
		int myId = inFromServer.readInt();
		String fileName = (String) inFromServer.readObject();
		int idClientRequesting = inFromServer.readInt();
		int port = inFromServer.readInt();
		//Connection with other peer
		Socket clientSocket = new Socket(InetAddress.getByName("localhost"), port);
		ObjectOutputStream outToClient = new ObjectOutputStream(clientSocket.getOutputStream());
		ObjectInputStream inFromClient = new ObjectInputStream(clientSocket.getInputStream());
		outToClient.writeObject("FileTransfer");
		outToClient.writeObject(fileName);
		//Read file
		System.out.println("This the file named: " + fileName);
		String line = (String) inFromClient.readObject();
		while (!line.equals("EOF")) {
			System.out.println(line);
			line = (String) inFromClient.readObject();
		}
		outToClient.writeObject("ACK: File correctly received");
		outToClient.close();
		inFromClient.close();
		clientSocket.close();
	}
	
	private class PeerDeamon extends Thread {
		
		private Socket socket;
		
		public PeerDeamon(Socket socketIn) {
			socket = socketIn;
		}
		
		@Override
		public void run(){
			try {
				ObjectOutputStream outToClient = new ObjectOutputStream(socket.getOutputStream());
				ObjectInputStream inFromClient = new ObjectInputStream(socket.getInputStream());
				String command = (String) inFromClient.readObject();
				switch (command) {
				case "DownloadRequest": 
					downloadRequest(inFromClient);
					break;
				case "DownloadConfirmation": 
					downloadConfirmation(inFromClient);
					break;
				case "FileTransfer": 
					new FileTransfer(socket, outToClient, inFromClient).start();
				}
				//Close socket and stream only if command is not FileTransfer
				//In that case, FileTransfer will close all of these
				if (!command.equals("FileTransfer")){
					outToClient.close();
					inFromClient.close();
					socket.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			};
		}
		
		private class FileTransfer extends Thread{
			
			private Socket socket;
			private ObjectOutputStream outToClient;
			private ObjectInputStream inFromClient;

			public FileTransfer(Socket socketIn, ObjectOutputStream outToClientIn, ObjectInputStream inFromClientIn) {
				socket = socketIn;
				outToClient = outToClientIn;
				inFromClient = inFromClientIn;
			}

			public void run() {
				try {
					String fileName = (String) inFromClient.readObject();
					File file = new File(fileName);
					if (file.exists()){
						BufferedReader brFile = new BufferedReader(new FileReader(file));
						String line = brFile.readLine();
						while (line != null){
							outToClient.writeObject(line);
							line = brFile.readLine();
						}
						outToClient.writeObject("EOF");
						brFile.close();
					} 
					outToClient.close();
					inFromClient.close();
					socket.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			
		}
	}
	
	public static void main(String[] args) throws Exception{
		//Client c = new Client(1, 5000, new ArrayList<>(Arrays.asList("kk.txt")));
		//c.logInRequest();
		//c.listRequest();
	}

}
