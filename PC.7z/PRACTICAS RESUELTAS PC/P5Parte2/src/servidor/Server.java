package servidor;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import utilidades.ClientInfo;

public class Server {
	
	static final int PORT = 9000;
	
	private ServerSocket serverSocket;
	private ConcurrentHashMap<Integer, ClientInfo> clients;
	private ConcurrentHashMap<String, List<Integer>> files;
	
	private Server() throws Exception{
		serverSocket = new ServerSocket(PORT);
		clients = new ConcurrentHashMap<>();
		files = new ConcurrentHashMap<>();
	}
	
	public void listen() throws Exception{
		while (true){
			System.out.println("Wating for client to connect...");
			Socket clientSocket = serverSocket.accept();
			System.out.println("Connection accepted...");
			new ClientListener(clientSocket).start();
		}
	}
	
	@SuppressWarnings("unchecked")
	private void login(ObjectInputStream inFromClient, ObjectOutputStream outToClient) throws Exception {
		int id = inFromClient.readInt();
		int puerto = inFromClient.readInt();
		ArrayList<String> filesFromClient = (ArrayList<String>) inFromClient.readObject();
		//A�adimos informacion a clients
		clients.put(id, new ClientInfo(puerto, filesFromClient));
		//A�adimos archivos a la lista de files
		for (String f: filesFromClient){
			if (!files.containsKey(f)){
				ArrayList<Integer> l = new ArrayList<>();
				l.add(id);
				files.put(f, l);
			}
			else {
				files.get(f).add(id);
			}
		}
		outToClient.writeObject("ACK: Login went right");
	}
	
	private void sendList(ObjectInputStream inFromClient, ObjectOutputStream outToClient) throws Exception {
		outToClient.writeObject(files);
		System.out.println((String) inFromClient.readObject());
	}
	
	private void download(ObjectInputStream inFromClient) throws Exception {
		//Read all data from client that requests to download
		int id = inFromClient.readInt();
		String fileName = (String) inFromClient.readObject();
		int targetId = inFromClient.readInt();
		//Advise target client of the request
		Socket targetClientSocket = new Socket(InetAddress.getByName("localhost"), clients.get(targetId).getPort());
		ObjectOutputStream outToTargetClient = new ObjectOutputStream(targetClientSocket.getOutputStream());
		outToTargetClient.writeObject("DownloadRequest");
		outToTargetClient.writeInt(targetId);
		outToTargetClient.writeObject(fileName);
		outToTargetClient.writeInt(id);
		outToTargetClient.close();
		targetClientSocket.close();
	}

	private void downloadConfirmation(ObjectInputStream inFromClient) throws Exception {
		//Read all data from client
		int id = inFromClient.readInt();
		String fileName = (String) inFromClient.readObject();
		int targetId = inFromClient.readInt();
		//Write all data received plus the por the target client
		ClientInfo clientInfoOfTarget = clients.get(targetId);
		Socket targetClientSocket = new Socket(InetAddress.getByName("localhost"), clientInfoOfTarget.getPort());
		ObjectOutputStream outToTargetClient = new ObjectOutputStream(targetClientSocket.getOutputStream());
		outToTargetClient.writeObject("DownloadConfirmation");
		outToTargetClient.writeInt(targetId);
		outToTargetClient.writeObject(fileName);
		outToTargetClient.writeInt(id);
		outToTargetClient.writeInt(clients.get(id).getPort());
		outToTargetClient.close();
		targetClientSocket.close();
	}

	private void logout() {
		// TODO Auto-generated method stub
	}
	
	private class ClientListener extends Thread {
		
		private Socket clientSocket;

		public ClientListener(Socket clientSocketIn){
			clientSocket = clientSocketIn;
		}
		
		@Override
		public void run() {
			try {
				ObjectOutputStream outToClient = new ObjectOutputStream(clientSocket.getOutputStream());
	            ObjectInputStream inFromClient = new ObjectInputStream(clientSocket.getInputStream());
	            switch ((String) inFromClient.readObject()) {
				case "Login":
					login(inFromClient, outToClient);
					break;
				case "List":
					sendList(inFromClient, outToClient);
					break;
				case "Download":
					download(inFromClient);
					break;
				case "DownloadConfirmation":
					downloadConfirmation(inFromClient);
					break;
				case "Logout":
					logout();
				}
				outToClient.close();
				inFromClient.close();
				clientSocket.close();
			} catch (Exception e) {
				e.printStackTrace();
			};

		}
		
	}
	
	public static void main(String[] args) throws Exception {
		new Server().listen();
	}
	
}
