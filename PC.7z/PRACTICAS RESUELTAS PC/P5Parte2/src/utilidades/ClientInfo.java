package utilidades;

import java.util.ArrayList;

public class ClientInfo {
	
	private int port;
	private ArrayList<String> files;
	
	public ClientInfo(int portIn, ArrayList<String> filesIn){
		port = portIn;
		files = filesIn;
	}

	public int getPort() {
		return port;
	}

	public ArrayList<String> getFiles() {
		return files;
	}

}
