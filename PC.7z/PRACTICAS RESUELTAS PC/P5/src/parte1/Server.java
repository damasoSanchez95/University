package parte1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = new ServerSocket(9999);
		while (true){
			System.out.println("Wating for client to connect...");
			Socket clientSocket = serverSocket.accept();
			System.out.println("Connection accepted...");
			BufferedWriter bwSocket = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
			BufferedReader brSocket = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			String fileName = brSocket.readLine();
			System.out.println(fileName);
			File file = new File(fileName);
			if (file.exists()){
				BufferedReader brFile = new BufferedReader(new FileReader(file));
				String line = brFile.readLine();
				while (line != null){
					bwSocket.write(line);
					bwSocket.newLine(); 
					bwSocket.flush();
					line = brFile.readLine();
				}
				brFile.close();
			}
			else {
				bwSocket.write("File does not exist");
				bwSocket.newLine();
				bwSocket.flush();
			}
			bwSocket.write("EOC");
			bwSocket.newLine();
			bwSocket.flush();
			bwSocket.close();
			clientSocket.close();
		}
	}

}
