package parte1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Random;

public class Client {
	
	static final int NUMCLIENTS = 1;
	static final Random RAND = new Random();
	
	public static void main(String[] args) throws IOException {
		for (int i = 0; i < NUMCLIENTS; i++){
			Socket clientSocket = new Socket("localHost", 9999);
			BufferedWriter bwSocket = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
			BufferedReader brSocket = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			if (RAND.nextInt(2) == 1){
				bwSocket.write("file1.txt");
				bwSocket.newLine();
				bwSocket.flush();
			}
			else {
				bwSocket.write("file2.txt");
				bwSocket.newLine();
				bwSocket.flush();
			}
			System.out.println("Waiting for response...");
			String line;
			do{
				line = brSocket.readLine();
				System.out.print(line);
			} while (!line.equals("EOC"));
			bwSocket.close();
			clientSocket.close();
		}
	}
}
