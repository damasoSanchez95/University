package avanzada.sync;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Productor extends Thread{
	
	private AlmacenDos buf;
	private Random r;
	
	public Productor(AlmacenDos al){
		buf = al;
		r = new Random();
	}

	@Override
	public void run(){
		int n = r.nextInt(5) + 1;
		List<Producto> productos = new ArrayList<>();
		for (int i = 0; i < n; i++) productos.add(new Producto());
		try {
			buf.almacenar(productos);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
