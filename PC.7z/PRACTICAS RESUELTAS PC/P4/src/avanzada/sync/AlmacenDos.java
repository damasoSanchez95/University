package avanzada.sync;

import java.util.List;

class AlmacenDos implements Almacen  {

	private Producto buffer[];
	private int ini, fin, k;
	private int empty, full;
	
	public AlmacenDos(int kIn){
		buffer = new Producto[kIn];
		for (int i = 0; i < k; i++) buffer[i] = new Producto(3);
		ini = 0;
		fin = 0;
		empty = kIn;
		full = 0;
		k = kIn;
	}
	
	@Override
	public synchronized void almacenar(List<Producto> productos) throws InterruptedException {
		while (empty < productos.size()) wait();
		empty = empty - productos.size();
		
		for (Producto p: productos){
			buffer[fin] = p;
			System.out.println("Entra " + buffer[fin]);
			fin = (fin + 1) % k;
		}
		
		full = full + productos.size();
		notifyAll();
	}

	@Override
	public synchronized void extraer(int n) throws InterruptedException {
		while (full < n) wait();
		full = full - n;
		
		for (int i = 0; i < n; i++){
			System.out.println("Sale " + buffer[ini]);
			ini = (ini + 1) % k;
		}
		
		empty = empty + n;
		notifyAll();
	}

	@Override
	public int ocupado() {
		return fin - ini;
	}

}
