package avanzada.sync;

import java.util.ArrayList;
import java.util.List;

public class Main {
	
	static int NC = 100;
	static int NP = 100;
	static int k = 5;
	
	public static void main(String args[]) throws InterruptedException{
		List<Consumidor> consumidores = new ArrayList<>();
		List<Productor> productores = new ArrayList<>();
		AlmacenDos al = new AlmacenDos(k);
		
		for (int i = 0; i < NC; i++){
			consumidores.add(new Consumidor(al));
		}
		
		for (int i = 0; i < NP; i++){
			productores.add(new Productor(al));
		}
		
		for (Consumidor c: consumidores){
			c.start();
		}
		
		for (Productor p: productores){
			p.start();
		}
		
		for (Consumidor c: consumidores){
			c.join();
		}
		
		for (Productor p: productores){
			p.join();
		}
		
	}
}
