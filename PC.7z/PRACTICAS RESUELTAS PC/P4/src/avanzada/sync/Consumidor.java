package avanzada.sync;

import java.util.Random;

public class Consumidor extends Thread{

	private AlmacenDos buf;
	private Random r;

	public Consumidor(AlmacenDos al) {
		buf = al;
		r = new Random();
	}

	@Override
	public void run(){
		try {
			buf.extraer(r.nextInt(5) + 1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
