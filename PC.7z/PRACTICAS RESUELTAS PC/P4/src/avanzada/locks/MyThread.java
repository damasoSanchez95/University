package avanzada.locks;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyThread extends Thread{
	private AlmacenDosMonitor m;
	private Boolean cond;
	private Random r;
	
	public MyThread(AlmacenDosMonitor m, Boolean cond){
		this.m=m;
		this.cond=cond;
		this.r = new Random();
	}
	
	public void run(){
		if(cond){
			try {
				m.extraer(r.nextInt(4) + 1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else {
			int n = r.nextInt(5) + 1;
			List<Producto> productos = new ArrayList<>();
			for (int i = 0; i < n; i++) productos.add(new Producto());
			try {
				m.almacenar(productos);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

