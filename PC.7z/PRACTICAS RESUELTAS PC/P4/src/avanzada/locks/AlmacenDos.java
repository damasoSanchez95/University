package avanzada.locks;

import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class AlmacenDosMonitor implements Almacen  {

	private Producto buffer[];
	private int ini, fin, k, empty, full;
	private Lock mutexP = new ReentrantLock();
	private Lock mutexC = new ReentrantLock();
	private Lock mutexE = new ReentrantLock();
	private Lock mutexF = new ReentrantLock();
	private Condition noSpace, noProducts;
	
	public AlmacenDosMonitor(int kIn){
		buffer = new Producto[kIn];
		for (int i = 0; i < k; i++) buffer[i] = new Producto(3);
		ini = 0;
		fin = 0;
		k = kIn;
		empty = kIn;
		full = 0;
		noSpace = mutexE.newCondition();
		noProducts = mutexF.newCondition();
	}
	
	@Override
	public void almacenar(List<Producto> productos) throws InterruptedException {
		
		mutexE.lock();
		while (empty < productos.size()) noSpace.await();
		empty = empty - productos.size();
		mutexE.unlock();
		
		mutexP.lock();
		
		//Almacena productos
		for (Producto p: productos){
			buffer[fin] = p;
			System.out.println("Entra " + buffer[fin]); System.out.flush();
			fin = (fin + 1) % k;
		}
		
		mutexP.unlock();
		
		mutexF.lock();
		full = full + productos.size();
		noProducts.signalAll();
		mutexF.unlock();
	}

	@Override
	public void extraer(int n) throws InterruptedException {
		
		mutexF.lock();
		while (full < n) noProducts.await();
		full = full - n;
		mutexF.unlock();
		
		mutexC.lock();
		
		//Extrae productos
		for (int i = 0; i < n; i++){
			System.out.println("Sale " + buffer[ini]); System.out.flush();
			ini = (ini + 1) % k;
		}
		
		mutexC.unlock();
		
		mutexE.lock();
		empty = empty + n;
		noSpace.signalAll();
		mutexE.unlock();
	}

	@Override
	public int ocupado() {
		return fin - ini;
	}

}
