package avanzada.locks;

import java.util.ArrayList;
import java.util.List;

public class Main {
	
	static int NC = 5;
	static int NP = 5;
	static int k = 5;
	
	public static void main(String args[]) throws InterruptedException{
		List<MyThread> consumidores = new ArrayList<>();
		List<MyThread> productores = new ArrayList<>();
		AlmacenDosMonitor al = new AlmacenDosMonitor(k);
		
		for (int i = 0; i < NC; i++){
			consumidores.add(new MyThread(al, true));
		}
		
		for (int i = 0; i < NP; i++){
			productores.add(new MyThread(al, false));
		}
		
		for (MyThread c: consumidores){
			c.start();
		}
		
		for (MyThread p: productores){
			p.start();
		}
		
		for (MyThread c: consumidores){
			c.join();
		}
		
		for (MyThread p: productores){
			p.join();
		}
		
	}
}
