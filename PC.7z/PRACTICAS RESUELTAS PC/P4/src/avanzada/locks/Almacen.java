package avanzada.locks;

import java.util.List;

public interface Almacen {
	
	public void almacenar(List<Producto> productos) throws InterruptedException;
	
	public void extraer(int n) throws InterruptedException;
	
	public int ocupado();
	
}
