package parte11;

public class MonitorEntero {
	
	private int num = 0;
	
	public synchronized void increment(){
		num++;
	}
	
	public synchronized void decrement(){
		num--;
	}
	
}
