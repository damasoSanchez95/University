package parte12;

import java.util.concurrent.Semaphore;

public class Productor extends Thread{
	
	private Semaphore empty, full;
	private AlmacenDos1 buf;
	
	public Productor(Semaphore emptyIn, Semaphore fullIn, AlmacenDos1 bufIn){
		empty = emptyIn;
		full = fullIn;
		buf = bufIn;
	}

	@Override
	public void run(){
		try {
			empty.acquire();
		} catch (InterruptedException e) {e.printStackTrace();}
		buf.almacenar(new Producto());
		full.release();
	}
	
}
