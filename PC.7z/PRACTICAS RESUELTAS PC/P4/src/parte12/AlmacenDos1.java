package parte12;

public class AlmacenDos1 {
	
	private AlmacenDos a;
	
	public AlmacenDos1(AlmacenDos aIn){
		a = aIn;
	}
	
	public synchronized void almacenar(Producto p){
		a.almacenar(p);
	}
	
}
