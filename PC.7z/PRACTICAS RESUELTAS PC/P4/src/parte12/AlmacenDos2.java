package parte12;

public class AlmacenDos2 {

	private AlmacenDos a;
	
	public AlmacenDos2(AlmacenDos aIn){
		a = aIn;
	}
	
	public synchronized Producto extraer(){
		return a.extraer();
	}
	
}
