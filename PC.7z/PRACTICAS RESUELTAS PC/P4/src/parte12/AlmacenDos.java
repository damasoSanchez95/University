package parte12;

class AlmacenDos implements Almacen {

	private Producto buffer[];
	private int ini, fin, k;
	
	public AlmacenDos(int kIn){
		buffer = new Producto[kIn];
		for (int i = 0; i < k; i++) buffer[i] = new Producto(3);
		ini = 0;
		fin = 0;
		k = kIn;
	}
	
	@Override
	public void almacenar(Producto producto) {
		System.out.println("Entra" + producto); System.out.flush();
		buffer[fin] = producto;
		fin = (fin + 1) % k;
	}

	@Override
	public Producto extraer() {
		Producto res = buffer[ini];
		ini = (ini + 1) % k;
		System.out.println("Saca " + res); System.out.flush();
		return res;
	}

	@Override
	public int ocupado() {
		return fin - ini;
	}

}
