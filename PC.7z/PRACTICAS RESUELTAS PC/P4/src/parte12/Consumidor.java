package parte12;

import java.util.concurrent.Semaphore;

public class Consumidor extends Thread{
	
	private Semaphore empty, full;
	private AlmacenDos2 buf;
	
	public Consumidor(Semaphore emptyIn, Semaphore fullIn, AlmacenDos2 bufIn){
		empty = emptyIn;
		full = fullIn;
		buf = bufIn;
	}

	@Override
	public void run(){
		try {
			full.acquire();
		} catch (InterruptedException e) { e.printStackTrace(); }
		buf.extraer();
		empty.release();
	}
}
