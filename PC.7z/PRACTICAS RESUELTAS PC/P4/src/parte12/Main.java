package parte12;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class Main {
	
	static int NC = 100;
	static int NP = 100;
	static int k = 5;
	
	public static void main(String args[]) throws InterruptedException{
		List<Consumidor> consumidores = new ArrayList<>();
		List<Productor> productores = new ArrayList<>();
		Semaphore empty = new Semaphore(k);
		Semaphore full = new Semaphore(0);
		AlmacenDos al = new AlmacenDos(k);
		AlmacenDos1 a1 = new AlmacenDos1(al);
		AlmacenDos2 a2 = new AlmacenDos2(al);
		
		for (int i = 0; i < NC; i++){
			consumidores.add(new Consumidor(empty, full, a2));
		}
		
		for (int i = 0; i < NP; i++){
			productores.add(new Productor(empty, full, a1));
		}
		
		for (Consumidor c: consumidores){
			c.start();
		}
		
		for (Productor p: productores){
			p.start();
		}
		
		for (Consumidor c: consumidores){
			c.join();
		}
		
		for (Productor p: productores){
			p.join();
		}
		
	}
}
