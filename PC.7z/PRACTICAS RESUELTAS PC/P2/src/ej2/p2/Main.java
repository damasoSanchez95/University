package ej2.p2;

public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		Lanzadera l = new Lanzadera();
		l.lanza();
	}

}
