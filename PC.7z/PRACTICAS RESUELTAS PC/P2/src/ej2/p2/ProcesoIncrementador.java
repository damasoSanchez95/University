package ej2.p2;

import ej1.Entero;

public class ProcesoIncrementador extends Proceso {
	
	public ProcesoIncrementador(int iIn, int[] inIn, int[] lastIn, Entero enteroIn, int nIn, int nIterIn) {
		super(iIn, inIn, lastIn, enteroIn, nIn, nIterIn);
	}

	@Override
	protected void seccionCritica() {
		Lanzadera.entero++;
	}

}
