package ej2.p2;

import ej1.Entero;

public abstract class Proceso extends Thread{
	
	private int i;
	private volatile int in[];
	private volatile int last[];
	private int n;
	
	//Variables de la SC
	volatile protected Entero entero;
	protected int nIter;
	
	public Proceso(int iIn, int inIn[], int lastIn[], Entero enteroIn, int nIn, int nIterIn){
		i = iIn;
		in = inIn;
		last = lastIn;
		entero = enteroIn;
		n = nIn;
		nIter = nIterIn;
	}
	
	protected abstract void seccionCritica();
	
	public void run(){
		for (int l = 0; l < nIter; l++){
			entryProtocol();
			seccionCritica();
			exitProtocol();
		}
	}
	
	private void entryProtocol(){
		for (int j = 1; j <= n; j++){
			Lanzadera.in[i] = j; Lanzadera.in = Lanzadera.in;
			Lanzadera.last[j] = i; Lanzadera.last = Lanzadera.last;
			for (int k = 1; k <= n; k++){
				if (k != i) 
					while (Lanzadera.in[k] >= Lanzadera.in[i] && Lanzadera.last[j] == i);
			}
		}
	}
	
	private void exitProtocol(){
		Lanzadera.in[i] = 0;
		Lanzadera.in = Lanzadera.in; //Crap
	}
}
