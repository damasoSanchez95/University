package ej2.p2;

import java.util.ArrayList;

import ej1.Entero;

public class Lanzadera {

	static private final int N = 100;
	static private final int NITER = 10;
	
	static volatile int[] in = new int[2*N + 1];
	static volatile int[] last = new int[2*N + 1];
	static volatile int entero;
	
	public void lanza() throws InterruptedException{
		ArrayList<Proceso> l = new ArrayList<>();
		
		for (int i = 1; i <= N; i++){
			l.add(new ProcesoDecrementador(i, in, last, null, 2*N, NITER));
		}
		
		for (int i = N + 1; i <= 2*N; i++){
			l.add(new ProcesoIncrementador(i, in, last, null, 2*N, NITER));
		}

		
		for (Proceso p: l){
			p.start();
		}
		
		for (Proceso p: l){
			p.join();
		}
		
		System.out.println(entero);
	}
	
}
