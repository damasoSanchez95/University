package ej2.rompe_empate;

import java.util.ArrayList;

import ej1.Entero;

public class Lanzadera {

	private final int N = 10;
	private final int NITER = 100;
	
	private volatile int[] in = new int[2*N + 1];
	private volatile int[] last = new int[2*N + 1];
	private volatile Entero entero = new Entero();
	
	public void lanza() throws InterruptedException{
		ArrayList<Proceso> l = new ArrayList<>();
		
		for (int i = 1; i <= N; i++){
			l.add(new ProcesoDecrementador(i, in, last, entero, 2*N, NITER));
		}
		
		for (int i = N + 1; i <= 2*N; i++){
			l.add(new ProcesoIncrementador(i, in, last, entero, 2*N, NITER));
		}

		
		for (Proceso p: l){
			p.start();
		}
		
		for (Proceso p: l){
			p.join();
		}
		
		System.out.println(entero.getValor());
	}
}
