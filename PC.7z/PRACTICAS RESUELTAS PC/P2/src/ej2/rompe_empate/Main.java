package ej2.rompe_empate;

public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		Lanzadera l = new Lanzadera();
		l.lanza();
	}

}
