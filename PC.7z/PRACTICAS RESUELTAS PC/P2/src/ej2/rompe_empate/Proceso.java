package ej2.rompe_empate;

import ej1.Entero;

public abstract class Proceso extends Thread{
	
	private int i;
	private int in[];
	private int last[];
	private int n;
	
	//Variables de la SC
	volatile protected Entero entero;
	protected int nIter;
	
	public Proceso(int iIn, int inIn[], int lastIn[], Entero enteroIn, int nIn, int nIterIn){
		i = iIn;
		in = inIn;
		last = lastIn;
		entero = enteroIn;
		n = nIn;
		nIter = nIterIn;
	}
	
	protected abstract void seccionCritica();
	
	public void run(){
		for (int l = 0; l < nIter; l++){
			entryProtocol();
			seccionCritica();
			exitProtocol();
		}
	}
	
	private void entryProtocol(){
		for (int j = 1; j <= n; j++){
			in[i] = j;
			last[j] = i;
			in = in; last = last; // Crap
			for (int k = 1; k <= n; k++){
				if (k == i) continue;
				else {
					while (in[k] >= in[i] && last[j] == i);
				}
			}
		}
	}
	
	private void exitProtocol(){
		in[i] = 0;
		in = in; //Crap
	}
}
