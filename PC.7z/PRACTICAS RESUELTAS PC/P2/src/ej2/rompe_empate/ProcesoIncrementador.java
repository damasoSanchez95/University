package ej2.rompe_empate;

import ej1.Entero;

public class ProcesoIncrementador extends Proceso {
	
	public ProcesoIncrementador(int iIn, int[] inIn, int[] lastIn, Entero enteroIn, int nIn, int nIterIn) {
		super(iIn, inIn, lastIn, enteroIn, nIn, nIterIn);
	}

	@Override
	protected void seccionCritica() {
		entero.incrementar();
		entero = entero;
	}

}
