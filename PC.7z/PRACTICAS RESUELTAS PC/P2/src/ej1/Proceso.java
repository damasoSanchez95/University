package ej1;

public class Proceso extends Thread{
	
	private Entero entero;
	private int n;
	private boolean incrementa;
	
	public Proceso(Entero enteroIn, int nIn, boolean incrementaIn){
		entero = enteroIn;
		n = nIn;
		incrementa = incrementaIn;
	}
	
	public void run(){
		if (incrementa) {
			incrementa();
		}
		else {
			decrementa();
		}
	}
	
	private void incrementa(){
		for (int i = 0; i < n; i++){
			Main.in1 = true;
			Main.last = 1;
			while (Main.in2 && Main.last == 1);
			entero.incrementar();
			Main.in1 = false;
		}		
	}
	
	private void decrementa(){
		for (int i = 0; i < n; i++){
			Main.in2 = true;
			Main.last = 2;
			while (Main.in1 && Main.last == 2);
			entero.decrementar();
			Main.in2 = false;
		}	
	}
	
}
