package ej1;

import java.util.ArrayList;

public class Main {
	
	static final int N = 10000000;
	static volatile boolean in1;
	static volatile boolean in2;
	static volatile int last;
	
	public static void main(String[] args) throws InterruptedException{
		Entero e = new Entero();
		ArrayList<Proceso> ps = new ArrayList<Proceso>();
		
		//Agregamos los procesos al array inicializandolos
		ps.add(new Proceso(e, N, true));
		ps.add(new Proceso(e, N, false));
		
		//Corremos todos los threads
		for (Proceso p: ps){
			p.start();
		}
		
		//Esperamos a que todos los threads terminen
		for (Proceso p: ps){
			p.join();
		}
		
		System.out.println("Valor del entero: " + e.getValor());
	}
	
}
