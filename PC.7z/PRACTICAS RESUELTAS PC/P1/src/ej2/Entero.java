package ej2;

public class Entero {
	
	private volatile int var;
	
	public Entero(){
		var = 0;
	}
	
	public void incrementar(){
		var += 1;
	}
	
	public void decrementar(){
		var -= 1;
	}
	
	public int getValor(){
		return var;
	}
}
