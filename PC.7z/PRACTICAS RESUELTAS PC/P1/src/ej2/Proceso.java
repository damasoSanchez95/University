package ej2;

public class Proceso extends Thread{
	
	private Entero entero;
	private int n;
	private boolean incrementa;
	
	public Proceso(Entero enteroIn, int nIn, boolean incrementaIn){
		entero = enteroIn;
		n = nIn;
		incrementa = incrementaIn;
	}
	
	public void run(){
		if (incrementa) {
			incrementa();
		}
		else {
			decrementa();
		}
	}
	
	private void incrementa(){
		for (int i = 0; i < n; i++)
			entero.incrementar();
	}
	
	private void decrementa(){
		for (int i = 0; i < n; i++)
			entero.decrementar();
	}
	
}
