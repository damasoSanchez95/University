package ej1;

public class Proceso extends Thread {
	
	private int id;
	private int tiempo;
	
	public Proceso(int idIn, int tiempoIn){
		id = idIn;
		tiempo = tiempoIn;
	}
	
	@Override
	public void run(){
		System.out.println(id);
		System.out.flush();
		try {
			sleep(tiempo);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(id);
		System.out.flush();
	}
}
