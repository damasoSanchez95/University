package ej1;

import java.util.ArrayList;
import java.util.Random;

public class Main {
	static final Random s = new Random();
	static final int N = 10;
	static final int TMax = 5;
	static int idGen = 0;	
	
	public static void main(String[] args) throws InterruptedException{
		ArrayList<Proceso> ps = new ArrayList<Proceso>();
		for (int i = 0; i < N; i++){
			ps.add(new Proceso(idGen++, s.nextInt(TMax)));
		}
		for (Proceso p: ps){
			p.start();
		}
		for (Proceso p: ps){
			p.join();
		}
		System.out.println("Todos los hilos han terminado");
		System.out.flush();
	}
}
