package basica;

public class AlmacenUno implements Almacen {
	
	private Producto buffer;

	@Override
	public void almacenar(Producto producto) {
		buffer = producto;
	}

	@Override
	public Producto extraer() {
		return buffer;
	}

	@Override
	public int ocupado() {
		if (buffer !=null)
			return 0;
		else
			return 1;
	}

}
