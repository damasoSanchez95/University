package basica;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class Main {
	
	static int NC = 1000;
	static int NP = 1000;
	
	public static void main(String args[]) throws InterruptedException{
		List<Consumidor> consumidores = new ArrayList<>();
		List<Productor> productores = new ArrayList<>();
		Semaphore empty = new Semaphore(1);
		Semaphore full = new Semaphore(0);
		AlmacenUno al = new AlmacenUno();
		
		
		
		for (int i = 0; i < NC; i++){
			consumidores.add(new Consumidor(empty, full, al));
		}
		
		for (int i = 0; i < NP; i++){
			productores.add(new Productor(empty, full, al));
		}
		
		for (Consumidor c: consumidores){
			c.start();
		}
		
		for (Productor p: productores){
			p.start();
		}
		
		for (Consumidor c: consumidores){
			c.join();
		}
		
		for (Productor p: productores){
			p.join();
		}
		
	}
}
