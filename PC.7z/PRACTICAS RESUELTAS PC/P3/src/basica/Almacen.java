package basica;

public interface Almacen {
	
	public void almacenar(Producto producto);
	
	public Producto extraer();
	
	public int ocupado();
	
}
