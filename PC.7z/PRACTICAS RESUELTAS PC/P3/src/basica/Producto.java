package basica;

import java.util.Random;

public class Producto {
	
	private int valor;
	
	public Producto(int i){
		this.valor=i;
	}
	
	public Producto() {
		valor = new Random().nextInt();
	}

	public int getValor(){
		return this.valor;
	}
	
	public void setValor(int valor){
		this.valor=valor;
	}
	
	@Override
	public String toString(){
		return valor + "";
	}
	
}