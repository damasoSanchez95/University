package basica;

import java.util.concurrent.Semaphore;

public class Consumidor extends Thread{
	
	private Semaphore empty, full;
	private AlmacenUno buf;
	
	public Consumidor(Semaphore emptyIn, Semaphore fullIn, AlmacenUno bufIn){
		empty = emptyIn;
		full = fullIn;
		buf = bufIn;
	}

	@Override
	public void run(){
		try {
			full.acquire();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(buf.extraer()); System.out.flush();
		empty.release();
	}
}
