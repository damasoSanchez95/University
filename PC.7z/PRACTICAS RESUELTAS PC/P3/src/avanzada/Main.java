package avanzada;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class Main {
	
	static int NC = 100;
	static int NP = 100;
	static int k = 5;
	
	public static void main(String args[]) throws InterruptedException{
		List<Consumidor> consumidores = new ArrayList<>();
		List<Productor> productores = new ArrayList<>();
		Semaphore empty = new Semaphore(k);
		Semaphore full = new Semaphore(0);
		Semaphore mutexP = new Semaphore(1);
		Semaphore mutexC = new Semaphore(1);
		AlmacenDos al = new AlmacenDos(k);
		
		for (int i = 0; i < NC; i++){
			consumidores.add(new Consumidor(empty, full, mutexC, al));
		}
		
		for (int i = 0; i < NP; i++){
			productores.add(new Productor(empty, full, mutexP, al));
		}
		
		for (Consumidor c: consumidores){
			c.start();
		}
		
		for (Productor p: productores){
			p.start();
		}
		
		for (Consumidor c: consumidores){
			c.join();
		}
		
		for (Productor p: productores){
			p.join();
		}
		
	}
}
