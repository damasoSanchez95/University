package avanzada;

import java.util.concurrent.Semaphore;

public class Consumidor extends Thread{
	
	private Semaphore empty, full, mutexC;
	private AlmacenDos buf;
	
	public Consumidor(Semaphore emptyIn, Semaphore fullIn, Semaphore mutexCIn, AlmacenDos bufIn){
		empty = emptyIn;
		full = fullIn;
		mutexC = mutexCIn;
		buf = bufIn;
	}

	@Override
	public void run(){
		try {
			full.acquire();
			mutexC.acquire();
		} catch (InterruptedException e) { e.printStackTrace(); }
		System.out.println("Saca " + buf.extraer()); System.out.flush();
		mutexC.release();
		empty.release();
	}
}
