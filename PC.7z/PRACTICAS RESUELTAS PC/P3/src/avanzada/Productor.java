package avanzada;

import java.util.concurrent.Semaphore;

import basica.Producto;

public class Productor extends Thread{
	
	private Semaphore empty, full, mutexP;
	private AlmacenDos buf;
	
	public Productor(Semaphore emptyIn, Semaphore fullIn, Semaphore mutexPIn, AlmacenDos bufIn){
		empty = emptyIn;
		full = fullIn;
		mutexP = mutexPIn;
		buf = bufIn;
	}

	@Override
	public void run(){
		try {
			empty.acquire();
			mutexP.acquire();
		} catch (InterruptedException e) {e.printStackTrace();}
		Producto p = new Producto();
		System.out.println("Entra" + p); System.out.flush();
		buf.almacenar(p);
		mutexP.release();
		full.release();
	}
	
}
