package alex;

public class AlexOperations {
  private AnalizadorLexicoTiny alex;
  public AlexOperations(AnalizadorLexicoTiny alex) {
   this.alex = alex;   
  }
  public UnidadLexica unidadId() {
     return new UnidadLexicaMultivaluada(alex.fila(),ClaseLexica.IDEN,
                                         alex.lexema()); 
  } 
  public UnidadLexica unidadNum() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.NUM); 
  }
  public UnidadLexica unidadBool() {
	     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.BOOL); 
  }
  public UnidadLexica unidadAnd() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.AND); 
  }   
  public UnidadLexica unidadOr() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.OR); 
  } 
  public UnidadLexica unidadNot() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.NOT); 
  } 
  public UnidadLexica unidadTrue() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.TRUE); 
  } 
  public UnidadLexica unidadFalse() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.FALSE); 
  } 
  
  public UnidadLexica unidadPAp() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.PARAP); 
  }
  public UnidadLexica unidadPCier() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.PARCIER); 
  }
  
  public UnidadLexica unidadSeccion() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.SECCION); 
  }
  public UnidadLexica unidadPYC() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.PYC); 
  }
  public UnidadLexica unidadIgual() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.IGUAL); 
  }
  public UnidadLexica unidadMas() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.MAS); 
  }
  public UnidadLexica unidadMenos() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.MENOS); 
  }
  public UnidadLexica unidadPor() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.POR); 
  }
  public UnidadLexica unidadDiv() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.DIV); 
  }
  public UnidadLexica unidadMayor() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.MAYOR); 
  }
  public UnidadLexica unidadMenor() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.MENOR); 
  }
  public UnidadLexica unidadBGET() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.BGET); 
  }
  public UnidadLexica unidadLWET() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.LWET); 
  }
  public UnidadLexica unidadDistinto() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.DISTINTO); 
  }
  public UnidadLexica unidadCompara() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.COMPARA); 
  }

  public UnidadLexica unidadNumero() {
     return new UnidadLexicaMultivaluada(alex.fila(),ClaseLexica.NUMERO,alex.lexema()); 
  } 
 
  public UnidadLexica unidadEof() {
     return new UnidadLexicaUnivaluada(alex.fila(),ClaseLexica.EOF); 
  }
  public void error() {
    System.err.println("***"+alex.fila()+" Caracter inexperado: "+alex.lexema());
  }
}
