/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package asint;

import alex.UnidadLexica;
import alex.AnalizadorLexicoTiny;
import alex.ClaseLexica;
import errors.GestionErroresTiny;
import java.io.IOException;
import java.io.Reader;


public class AnalizadorSintacticoTiny {
   private UnidadLexica anticipo;
   private AnalizadorLexicoTiny alex;
   private GestionErroresTiny errores;
   public AnalizadorSintacticoTiny(Reader input) {
      errores = new GestionErroresTiny();
      alex = new AnalizadorLexicoTiny(input);
      alex.fijaGestionErrores(errores);
      sigToken();
   }
   
   private void empareja(ClaseLexica claseEsperada) {
	      if (anticipo.clase() == claseEsperada)
	          sigToken();
	      else errores.errorSintactico(anticipo.fila(),anticipo.clase(),claseEsperada);
	   }
   private void sigToken() {
      try {
        anticipo = alex.yylex();
      }
      catch(IOException e) {
        errores.errorFatal(e);
      }
   }
   
   
   
   public void Programa() {
	   switch(anticipo.clase()) {
	       case NUM:          
	            LIs();
	            break;
	       case BOOL:
	           LIs();
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.NUM,ClaseLexica.BOOL);                                            
		   }
      empareja(ClaseLexica.EOF);
   }
   
   
   
   
   private void LIs() {
	   switch(anticipo.clase()) {
	       case NUM:          
	           DIs();
	           empareja(ClaseLexica.SECCION);
	           AIs();
	           break;
	       case BOOL:
	    	   DIs();
	           empareja(ClaseLexica.SECCION);
	           AIs();
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.NUM,ClaseLexica.BOOL);                                            
		   }
   }
   
   
   private void DIs() {
	   switch(anticipo.clase()) {
	       case NUM:          
	            Declaracion();
	            RDIs();
	            break;
	       case BOOL:
	    	   Declaracion();
	           RDIs();
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.NUM,ClaseLexica.BOOL);                                            
		   }
   }
   
   private void RDIs() {
	   switch(anticipo.clase()) {
	       case PYC:          
	            empareja(ClaseLexica.PYC);
	            Declaracion();
	            RDIs();
	            break;
	       case SECCION:
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.PYC,ClaseLexica.SECCION);                                            
		   }
   }

   private void AIs() {
	   switch(anticipo.clase()) {
	       case IDEN:          
	            Asignacion();
	            RAIs();
	            break;
	       case EOF:
	    	   Asignacion();
	    	   RAIs();
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.IDEN,ClaseLexica.EOF);                                            
		   }
   }
   
   
   private void RAIs() {
	   switch(anticipo.clase()) {
	       case PYC:          
	            empareja(ClaseLexica.PYC);
	            Asignacion(); 
	            RAIs();
	            break;
	       case EOF:
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.PYC,ClaseLexica.EOF);                                            
		   }
   }
   
   private void Declaracion() {
	   switch(anticipo.clase()) {
	       case NUM:          
	            empareja(ClaseLexica.NUM);
	            empareja(ClaseLexica.IDEN);
	            break;
	       case BOOL:
	    	   empareja(ClaseLexica.BOOL);
	           empareja(ClaseLexica.IDEN);
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.BOOL,ClaseLexica.NUM);                                            
		   }
   }

   private void Asignacion() {
	   switch(anticipo.clase()) {
	       case IDEN:          
	            empareja(ClaseLexica.IDEN);
	            empareja(ClaseLexica.IGUAL);
	            Exp0();
	            break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.IDEN);                                            
		   }
   }
   
   private void OpBin0() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	            empareja(ClaseLexica.MENOS);
	            break;
	       case MAS:
	    	   empareja(ClaseLexica.MAS);
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.MAS);                                            
		   }
   }

   
   private void OpAnd() {
	   switch(anticipo.clase()) {
	       case AND:          
	            empareja(ClaseLexica.AND);
	            break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.AND);                                            
		   }
   }
   private void OpOr() {
	   switch(anticipo.clase()) {
	       case OR:          
	            empareja(ClaseLexica.OR);
	            break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.OR);                                            
		   }
   }
   private void OpBin2() {
	   switch(anticipo.clase()) {
	       case LWET:          
	            empareja(ClaseLexica.LWET);
	            break;
	       case BGET:
	    	   empareja(ClaseLexica.BGET);
	           break;
	       case MENOR:          
	            empareja(ClaseLexica.MENOR);
	            break;
	       case MAYOR:
	    	   empareja(ClaseLexica.MAYOR);
	           break;
	       case IGUAL:          
	            empareja(ClaseLexica.IGUAL);
	            break;
	       case DISTINTO:
	    	   empareja(ClaseLexica.DISTINTO);
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.LWET,ClaseLexica.BGET,ClaseLexica.MENOR,ClaseLexica.MAYOR,ClaseLexica.IGUAL,ClaseLexica.DISTINTO);                                            
		   }
   }
   
   private void OpBin3() {
	   switch(anticipo.clase()) {
	       case DIV:          
	            empareja(ClaseLexica.DIV);
	            break;
	       case POR:
	    	   empareja(ClaseLexica.POR);
	           break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.DIV,ClaseLexica.POR);                                            
		   }
   }
   
   private void OpUnMenos() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	            empareja(ClaseLexica.MENOS);
	            break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS);                                            
		   }
   }
   
   private void OpUnNot() {
	   switch(anticipo.clase()) {
	       case NOT:          
	            empareja(ClaseLexica.NOT);
	            break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.NOT);                                            
		   }
   }

 
   private void Exp0() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	    	    Exp1();
	    	    RExp0();
	            break;
	       case NOT:
	    	    Exp1();
	    	    RExp0();
	            break;
	       case NUMERO:          
	    	    Exp1();
	    	    RExp0();
	            break;
	       case IDEN:
	    	    Exp1();
	    	    RExp0();
	            break;
	       case PARAP:          
	    	    Exp1();
	    	    RExp0();
	            break;
	       case TRUE:
	    	    Exp1();
	    	    RExp0();
	            break;
	       case FALSE:
	    	    Exp1();
	    	    RExp0();
	            break;
	       
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.NOT,ClaseLexica.NUMERO,ClaseLexica.IDEN,ClaseLexica.PARAP,
	                                        ClaseLexica.TRUE,ClaseLexica.FALSE);                                            
		   }
   }
   
   
   private void RExp0() {
	   switch(anticipo.clase()) {
	       case MENOS: 
	    	    OpBin0();
	    	    Exp1();
	    	    RExp0();
	            break;
	       case MAS:
	    	   OpBin0();
	    	   Exp1();
	    	   RExp0();
	           break;
	       case PARCIER: 
	            break;
	       case PYC:
	           break;
	       case EOF: 
	            break;
	      
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.MAS,ClaseLexica.PARCIER,ClaseLexica.PYC,ClaseLexica.EOF);                                            
		   }
   }
   
   private void Exp1() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	    	    Exp2();
	    	    RExp1();
	            break;
	       case NOT:
	    	    Exp2();
	    	    RExp1();
	            break;
	       case NUMERO:          
	    	    Exp2();
	    	    RExp1();
	            break;
	       case IDEN:
	    	    Exp2();
	    	    RExp1();
	            break;
	       case PARAP:          
	    	    Exp2();
	    	    RExp1();
	            break;
	       case TRUE:
	    	    Exp2();
	    	    RExp1();
	            break;
	       case FALSE:
	    	    Exp2();
	    	    RExp1();
	            break;
	       
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.NOT,ClaseLexica.NUMERO,ClaseLexica.IDEN,ClaseLexica.PARAP,
	                                        ClaseLexica.TRUE,ClaseLexica.FALSE);                                            
		   }
   }
   
   private void RExp1() {
	   switch(anticipo.clase()) {
	       case AND: 
	    	    OpAnd();
	    	    Exp1();
	            break;
	       case OR:
	    	    OpOr();
	    	    Exp2();
	            break;
	       case PARCIER: 
	            break;
	       case MENOS: 
	            break;
	       case MAS:
	           break;
	       case PYC:
	           break;
	       case EOF: 
	            break;
	      
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	    		   							ClaseLexica.AND,ClaseLexica.OR,ClaseLexica.PARCIER,
	    		   							ClaseLexica.MAS,ClaseLexica.PYC,ClaseLexica.EOF);                                            
		   }
   }
   
   
   private void Exp2() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	    	    Exp3();
	    	    RExp2();
	            break;
	       case NOT:
	    	   	Exp3();
	    	    RExp2();
	            break;
	       case NUMERO:          
	    	   	Exp3();
	    	    RExp2();
	            break;
	       case IDEN:
	    	   	Exp3();
	    	    RExp2();
	            break;
	       case PARAP:          
	    	   	Exp3();
	    	    RExp2();
	            break;
	       case TRUE:
	    	    Exp3();
	    	    RExp2();
	            break;
	       case FALSE:
	    	    Exp3();
	    	    RExp2();
	            break;
	       
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.NOT,ClaseLexica.NUMERO,ClaseLexica.IDEN,ClaseLexica.PARAP,
	                                        ClaseLexica.TRUE,ClaseLexica.FALSE);                                            
		   }
   }
   
   private void RExp2() {
	   switch(anticipo.clase()) {
	       case LWET:          
	    	   	OpBin2();
	    	   	Exp3();
	            break;
	       case BGET:
	    	   	OpBin2();
	    	   	Exp3();
	    	   	break;
	       case MENOR:          
	    	   	OpBin2();
	    	   	Exp3();
	    	   	break;
	       case MAYOR:
	    	   	OpBin2();
	    	   	Exp3();
	    	   	break;
	       case IGUAL:          
	    	   	OpBin2();
	    	   	Exp3();
	    	   	break;
	       case DISTINTO:          
	    	   	OpBin2();
	    	   	Exp3();
	    	   	break;
	       case PARCIER: 
	            break;
	       case AND: 
	    	   	break;
	       case OR:
	            break;
	       case MENOS: 
	            break;
	       case MAS:
	           break;
	       case PYC:
	           break;
	       case EOF: 
	            break;
	       
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.LWET,ClaseLexica.BGET,ClaseLexica.MENOR,ClaseLexica.MAYOR,ClaseLexica.IGUAL,
	                                        ClaseLexica.DISTINTO,ClaseLexica.PARCIER,ClaseLexica.AND,ClaseLexica.OR,ClaseLexica.MENOS,
	                                        ClaseLexica.MAS,ClaseLexica.PYC,ClaseLexica.EOF);                                            
		   }
   }
   

   private void Exp3() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	    	    Exp4();
	    	    RExp3();
	            break;
	       case NOT:
	    	   	Exp4();
	    	    RExp3();
	            break;
	       case NUMERO:          
	    	   	Exp4();
	    	    RExp3();
	            break;
	       case IDEN:
	    	   	Exp4();
	    	    RExp3();
	            break;
	       case PARAP:          
	    	   	Exp4();
	    	    RExp3();
	            break;
	       case TRUE:
	    	    Exp4();
	    	    RExp3();
	            break;
	       case FALSE:
	    	    Exp4();
	    	    RExp3();
	            break; 
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.NOT,ClaseLexica.NUMERO,ClaseLexica.IDEN,ClaseLexica.PARAP,
	                                        ClaseLexica.TRUE,ClaseLexica.FALSE);                                            
		   }
   }
   

   private void RExp3() {
	   switch(anticipo.clase()) {
	       case DIV:          
	    	    OpBin3();
	    	    Exp4();
	    	    RExp3();
	            break;
	       case POR:
	    	    OpBin3();
	    	    Exp4();
	    	    RExp3();
	            break;
	       case PARCIER:          
	            break;
	       case LWET:
	            break;
	       case BGET:          
	            break;
	       case MENOR:          
	            break;
	       case MAYOR:
	            break;
	       case IGUAL:          
	            break;
	       case DISTINTO:          
	            break;
	       case AND:
	            break;
	       case OR:          
	            break;
	       case MENOS:          
	            break;
	       case MAS:
	            break;
	       case PYC:          
	            break;
	       case EOF:          
	            break;

	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.DIV,ClaseLexica.POR,ClaseLexica.PARCIER,ClaseLexica.LWET,ClaseLexica.BGET,
	                                        ClaseLexica.MENOR,ClaseLexica.MAYOR,ClaseLexica.IGUAL,ClaseLexica.DISTINTO,ClaseLexica.AND,
	                                        ClaseLexica.OR,ClaseLexica.MENOS,ClaseLexica.MAS,ClaseLexica.PYC,ClaseLexica.EOF);                                            
		   }
   }
   
   private void Exp4() {
	   switch(anticipo.clase()) {
	       case MENOS:          
	    	   	OpUnMenos();
	    	   	Exp4();
	            break;
	       case NOT:
	    	   	OpUnNot();
	    	   	Exp5();
	    	   	break;
	       case NUMERO:          
	    	   	Exp5();
	    	   	break;
	       case IDEN:
	    	   	Exp5();
	    	   	break;
	       case PARAP:          
	    	   	Exp5();
	    	   	break;
	       case TRUE:
	    	    Exp5();
	            break;
	       case FALSE:
	    	    Exp5();
	            break;
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.MENOS,ClaseLexica.NOT,ClaseLexica.NUMERO,ClaseLexica.IDEN,ClaseLexica.PARAP,
	                                        ClaseLexica.TRUE,ClaseLexica.FALSE);                                            
		   }
   }
   
   private void Exp5() {
	   switch(anticipo.clase()) {
	       case TRUE:
	    	   	empareja(ClaseLexica.TRUE);
	            break;
	       case FALSE:
	    	   	empareja(ClaseLexica.FALSE);
	            break;
	       case NUMERO:          
	    	   	empareja(ClaseLexica.NUMERO);
	            break;
	       case IDEN:
	    	   	empareja(ClaseLexica.IDEN);
	            break;
	       case PARAP:          
	    	   	empareja(ClaseLexica.PARAP);
	    	   	Exp0();
	    	   	empareja(ClaseLexica.PARCIER);
	            break;
	       
	       default: errores.errorSintactico(anticipo.fila(),anticipo.clase(),
	                                        ClaseLexica.TRUE,ClaseLexica.FALSE,ClaseLexica.NUMERO,ClaseLexica.IDEN,ClaseLexica.PARAP);                                            
		   }
   }
   
}
