package alex;

import java.io.FileInputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.IOException;

public class AnalizadorLexicoTiny {

   private Reader input;
   private StringBuffer lex;
   private int sigCar;
   private int filaInicio;
   private int columnaInicio;
   private int filaActual;
   private int columnaActual;
   private static String NL = System.getProperty("line.separator");
   
   private static enum Estado {
	   INICIO, REC_SECCION1, REC_MAS, REC_NUM1, REC_MENOS, REC_E, REC_POR, REC_NUM2, REC_DIV, REC_SIGNO,REC_PARAP, REC_NUM3, REC_PARCIER, REC_IDENT, REC_PYC, REC_SECCION2,
	   REC_PUNTO, REC_DIST1, REC_IGUAL, REC_COMP, REC_MAYOR, REC_MENOR, REC_BGET, REC_LWET, REC_DIST2, REC_EOF
   }

   private Estado estado;

   public AnalizadorLexicoTiny(Reader input) throws IOException {
    this.input = input;
    lex = new StringBuffer();
    sigCar = input.read();
    filaActual=1;
    columnaActual=1;
   }
   
   public UnidadLexica sigToken() throws IOException {
     estado = Estado.INICIO;
     filaInicio = filaActual;
     columnaInicio = columnaActual;
     lex.delete(0,lex.length());
     while(true) {
         switch(estado) {
           case INICIO: 
              if(hayLetra())  transita(Estado.REC_IDENT);
              else if (hayDigito()) transita(Estado.REC_NUM1);
              else if (haySuma()) transita(Estado.REC_MAS);
              else if (hayResta()) transita(Estado.REC_MENOS);
              else if (hayMul()) transita(Estado.REC_POR);
              else if (hayDiv()) transita(Estado.REC_DIV);
              else if (hayPAp()) transita(Estado.REC_PARAP);
              else if (hayPCierre()) transita(Estado.REC_PARCIER);
              else if (hayMenor()) transita(Estado.REC_MENOR);
              else if (hayMayor()) transita(Estado.REC_MAYOR);
              else if (hayIgual()) transita(Estado.REC_IGUAL);
              else if (hayPyC()) transita(Estado.REC_PYC);
              else if (hayExclamacion()) transita(Estado.REC_DIST1);
              else if (hayAmper()) transita(Estado.REC_SECCION1);
              else if (haySep()) transitaIgnorando(Estado.INICIO);
              else if (hayEOF()) transita(Estado.REC_EOF);
              else error();
              break;
           case REC_IDENT: 
              if (hayLetra() || hayDigito() || hayGuion()) transita(Estado.REC_IDENT);
              else return unidadId();               
              break;
           case REC_MAS:
               if (hayDigito()) transita(Estado.REC_NUM1);
               else return unidadMas();
               break;
           case REC_MENOS: 
               if (hayDigito()) transita(Estado.REC_NUM1);
               else return unidadMenos();
               break;
           case REC_POR: return unidadPor();
           case REC_DIV: return unidadDiv();              
           case REC_PARAP: return unidadPAp();
           case REC_PARCIER: return unidadPCierre();
           case REC_IGUAL:  
        	   if (hayIgual()) transita(Estado.REC_COMP);
	           else return unidadIgual();
	           break;
           case REC_PYC: return unidadPyC();
           case REC_COMP: return unidadComp();
           case REC_EOF: return unidadEof();
           case REC_MENOR: 
               if (hayIgual()) transita(Estado.REC_LWET);
               else return unidadMenor();
               break;
           case REC_LWET: return unidadLWET();
           case REC_BGET: return unidadBGET();
           case REC_MAYOR: 
               if (hayIgual()) transita(Estado.REC_BGET);
               else return unidadMayor();
               break;
           case REC_DIST1: 
               if (hayIgual()) transita(Estado.REC_DIST2);
               break;
           case REC_DIST2: return unidadDist();
           case REC_SECCION1: 
               if (hayAmper()) transita(Estado.REC_SECCION2);
               else error();
               break;
           case REC_SECCION2: return unidadSeccion();
           case REC_NUM1: 
               if (hayPunto()) transita(Estado.REC_PUNTO);
               else if(hayE()) transita(Estado.REC_E);
               else if(hayDigito()) transita(Estado.REC_NUM1);
               else return unidadNum();
               break;
           case REC_PUNTO: 
               if (hayDigito()) transita(Estado.REC_NUM2);
               else error();
               break;
           case REC_NUM2: 
               if (hayDigito()) transita(Estado.REC_NUM2);
               else if(hayE()) transita(Estado.REC_E);
               else return unidadNum();
               break;
           case REC_E: 
               if (haySuma() || hayResta()) transita(Estado.REC_SIGNO);
               else if(hayDigito()) transita(Estado.REC_NUM3);
               else error();
               break;
           case REC_SIGNO: 
               if (hayDigito()) transita(Estado.REC_NUM3);
               else error();
               break;
           case REC_NUM3:
        	   if(hayDigito()) transita(Estado.REC_NUM3);
        	   else return unidadNum();
           
           
           
           
           
           
         }
     }    
   }


private void transita(Estado sig) throws IOException {
     lex.append((char)sigCar);
     sigCar();         
     estado = sig;
   }
   private void transitaIgnorando(Estado sig) throws IOException {
     sigCar();         
     filaInicio = filaActual;
     columnaInicio = columnaActual;
     estado = sig;
   }
   private void sigCar() throws IOException {
     sigCar = input.read();
     if (sigCar == NL.charAt(0)) saltaFinDeLinea();
     if (sigCar == '\n') {
        filaActual++;
        columnaActual=0;
     }
     else {
       columnaActual++;  
     }
   }
   private void saltaFinDeLinea() throws IOException {
      for (int i=1; i < NL.length(); i++) {
          sigCar = input.read();
          if (sigCar != NL.charAt(i)) error();
      }
      sigCar = '\n';
   }
   
   private boolean hayLetra() {return sigCar >= 'a' && sigCar <= 'z' ||
                                      sigCar >= 'A' && sigCar <= 'Z';}
   private boolean hayDigito() {return sigCar >= '0' && sigCar <= '9';}
   private boolean haySuma() {return sigCar == '+';}
   private boolean hayResta() {return sigCar == '-';}
   private boolean hayMul() {return sigCar == '*';}
   private boolean hayDiv() {return sigCar == '/';}
   private boolean hayPAp() {return sigCar == '(';}
   private boolean hayPCierre() {return sigCar == ')';}
   private boolean hayIgual() {return sigCar == '=';}
   private boolean hayPyC() {return sigCar == ';';}
   private boolean hayPunto() {return sigCar == '.';}
   private boolean haySep() {return sigCar == ' ' || sigCar == '\t' || sigCar=='\n' || sigCar == '\b' || sigCar == '\r';}
   private boolean hayEOF() {return sigCar == -1;}
   private boolean hayMayor() {return sigCar == '>';}
   private boolean hayMenor() {return sigCar == '<';}
   private boolean hayAmper() {return sigCar == '&';}
   private boolean hayExclamacion() {return sigCar == '!';}
   private boolean hayGuion() {return sigCar == '_';}
   private boolean hayE() {return sigCar == 'e' || sigCar == 'E';}



   private UnidadLexica unidadId() {
     switch(lex.toString()) {
         case "num":  
            return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.NUM);
         case "bool":    
            return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.BOOL);
         case "true":    
             return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.TRUE);
         case "false":    
             return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.FALSE);
         case "and":    
             return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.AND);
         case "or":    
             return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.OR);
         case "not":    
             return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.NOT);
         default:    
            return new UnidadLexicaMultivaluada(filaInicio,columnaInicio,ClaseLexica.IDEN,lex.toString());     
      }
   }
   
	private UnidadLexica unidadSeccion() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.SECCION);     
	}
	
	private UnidadLexica unidadDist() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.DISTINTO);     
	}
	
	private UnidadLexica unidadMayor() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.MAYOR);     
	}
	
	private UnidadLexica unidadBGET() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.BGET);     
	}
	
	private UnidadLexica unidadLWET() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.LWET);     
	}
	
	private UnidadLexica unidadMenor() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.MENOR);     
	}
	
	private UnidadLexica unidadComp() {
	     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.COMPARA);     
	}
   private UnidadLexica unidadNum() {
     return new UnidadLexicaMultivaluada(filaInicio,columnaInicio,ClaseLexica.NUMERO,lex.toString());     
   }    
   private UnidadLexica unidadMas() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.MAS);     
   }    
   private UnidadLexica unidadMenos() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.MENOS);     
   }    
   private UnidadLexica unidadPor() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.POR);     
   }    
   private UnidadLexica unidadDiv() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.DIV);     
   }    
   private UnidadLexica unidadPAp() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.PARAP);     
   }    
   private UnidadLexica unidadPCierre() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.PARCIER);     
   }    
   private UnidadLexica unidadIgual() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.IGUAL);     
   }    
   private UnidadLexica unidadPyC() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.PYC);     
   }    
   private UnidadLexica unidadEof() {
     return new UnidadLexicaUnivaluada(filaInicio,columnaInicio,ClaseLexica.EOF);     
   }    
   private void error() {
     System.err.println("("+filaActual+','+columnaActual+"):Caracter inexperado");  
     System.exit(1);
   }

   public static void main(String arg[]) throws IOException {
     Reader input = new InputStreamReader(new FileInputStream("input.txt"));
     AnalizadorLexicoTiny al = new AnalizadorLexicoTiny(input);
     UnidadLexica unidad;
     do {
       unidad = al.sigToken();
       System.out.println(unidad);
     }
     while (unidad.clase() != ClaseLexica.EOF);
    } 
}