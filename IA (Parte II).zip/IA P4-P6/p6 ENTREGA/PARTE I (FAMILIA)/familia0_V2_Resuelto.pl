persona(juan, hombre).
persona(maria, mujer).
persona(rosa, mujer).
persona(luis, hombre).
persona(jose, hombre).
persona(laura, mujer).
persona(pilar, mujer).
persona(miguel, hombre).
persona(isabel, mujer).
persona(jaime, hombre).
persona(pedro, hombre).
persona(pablo, hombre).
persona(begonia, mujer).

progenitores(juan, maria, rosa).
progenitores(maria, juan, luis).
progenitores(jose, laura, pilar).
progenitores(pilar, luis, miguel).
progenitores(miguel, isabel, jaime).
progenitores(pedro, rosa, pablo).
progenitores(pedro, rosa, begonia).

/* Predicado que saca los padres ya esten en el primer argumento de progenitores o en el segundo*/
padre(X, Y):- progenitores(X, _, Y) , persona(X, hombre).
padre(X, Y):- progenitores(_, X, Y) , persona(X, hombre).

/* predicado que saca las madres ya esten en el primer argumento de progenitores o en el segundo*/
madre(X, Y):- progenitores(_, X, Y) , persona(X, mujer).
madre(X, Y):- progenitores(X, _, Y) , persona(X, mujer).

/* Predicados auxiliares*/

/* Saca los hijos de los padres */

hijoPadre(X, Y):- progenitores(Y, _, X) , persona(X, hombre) , persona(Y, hombre).
hijoPadre(X, Y):- progenitores(_, Y, X) , persona(X, hombre) , persona(Y, hombre).

/* Saca los hijos de las madres*/

hijoMadre(X, Y):- progenitores(_, Y, X) , persona(X, hombre) , persona(Y, mujer).
hijoMadre(X, Y):- progenitores(Y, _, X) , persona(X, hombre) , persona(Y, mujer).

/* Saca las hijas de los padres*/

hijaPadre(X, Y):- progenitores(Y, _, X) , persona(X, mujer) , persona(Y, hombre).
hijaPadre(X, Y):- progenitores(_, Y, X) , persona(X, mujer) , persona(Y, hombre).

/* Saca las hijas de las madres*/

hijaMadre(X, Y):- progenitores(Y, _, X) , persona(X, mujer) , persona(Y, mujer).
hijaMadre(X, Y):- progenitores(_, Y, X) , persona(X, mujer) , persona(Y, mujer).

/* Saca los hijos de las madres y padres*/

hijo(X, Y):- hijoPadre(X, Y).
hijo(X, Y):- hijoMadre(X, Y).

/* Saca los hijas de las madres y padres*/

hija(X, Y):- hijaPadre(X, Y).
hija(X, Y):- hijaMadre(X,Y).

/* Predicado generico para sacar todos los hijos/hijas de los padres/madres */

hijo_generico(X, Y):- hijoPadre(X, Y).
hijo_generico(X, Y):- hijoMadre(X, Y).
hijo_generico(X, Y):- hijaPadre(X, Y).
hijo_generico(X, Y):- hijaMadre(X, Y).

/* Predicado para sacar todos los hermanos*/

hermano(X, Y):- padre(P,X), madre(M,X), padre(P, Y), madre(M, Y), persona(X, hombre) , X\=Y.

/* Predicado para sacar todas las hermanas*/

hermana(X, Y):- padre(P,X), madre(M,X), padre(P, Y), madre(M, Y), persona(X, mujer), X\=Y.

/* Predicado generico para sacar todos los hermanos/hermanas*/

hermano_generico(X, Y):- hermano(X, Y).
hermano_generico(X, Y):- hermana(X, Y).

/* Predicado para sacar todos los abuelos*/

abueloPaterno(X, Y):- padre(X,P) , padre(P, Y).
abueloMaterno(X, Y):- padre(X, M) , madre(M, Y).

abuelo(X, Y):- abueloPaterno(X, Y).
abuelo(X, Y):- abueloMaterno(X, Y).

/* Predicado para sacar todas las abuelas*/

abuelaPaterna(X, Y):- madre(X,P), padre(P, Y).
abuelaMaterna(X, Y):- madre(X, M), madre(M, Y).

abuela(X, Y):- abuelaPaterna(X, Y).
abuela(X, Y):- abuelaMaterna(X, Y).

/* Predicado para sacar todos los primos*/

primo(X, Y):- hijo(X, Z), hijo_generico(Y, W), hermano_generico(Z, W), X \= Y , not(hermano_generico(X, Y)).

/* Predicado para sacar todas las primas*/

prima(X, Y):- hija(X, Z), hijo_generico(Y,W), hermano_generico(Z, W), X \=Y , not(hermano_generico(X, Y)).

/* Predicado para sacar todos los ascendientes de una persona*/

ascendiente(X, Y):- hijo_generico(Y, X).
ascendiente(X, Y):- hijo_generico(Z, X), ascendiente(Z, Y).






