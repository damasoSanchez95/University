/*REPRESENTACION DE ESTADOS DEL PROBLEMA: */

estado(garrafaC1,garrafaC2).

/*Donde garrafaC1L y garrafaC2L son la cantidad de agua que quedan en las garrafas respectivamente. */

/*ESTADO INICIAL: Asumimos que Inicialmente las garrafas estan vacias, es decir contendrán 0 litros.*/

inicial(estado(0,0)).

/*ESTADO OBJETIVO: El estado objetivo es aquel que tiene exactamente L litros de agua en cualquiera de las jarras.*/

objetivo(estado(L,_), L).
objetivo(estado(_,L), L).

/*OPERADORES:

 Explicitar las transformaciones de estados mediante un predicado
 movimiento:

	  movimiento(Estado, EstadoSiguiente, Operador)
                         :- Especificacion
*/

/*LLENAR GARRAFA C1L. No nos importa la garrafa de C2L*/
movimiento(estado(X, Y), estado(Z, Y), llenarC1(X, Z), C1, _) :- (X < C1) , Z is C1.

/*LLENAR GARRAFA C2L. No nos importa la garrafa de C1L*/
movimiento(estado(X, Y), estado(X, Z), llenarC2(Y, Z),_, C2) :- (Y < C2) , Z is C2.

/*VACIAR GARRAFA C1L*/

movimiento(estado(X, Y), estado(Z, Y), vaciarC1(X, Z), _, _) :- (X > 0) , Z is 0 .

/*VACIAR GARRAFA C2L*/

movimiento(estado(X, Y), estado(X, Z), vaciarC2(Y, Z), _, _) :- (Y > 0) , Z is 0 .

/*ECHAR GARRAFA C1L EN C2L*/

movimiento(estado(X, Y), estado(Z, T), echarC1enC2(X, Y), _, C2) :- (X > 0) , (Y < C2) , (Z is (X - min(C2, X + Y) + Y) , T is (min( C2, X + Y))).

/*ECHAR GARRAFA C2L EN C1L*/

movimiento(estado(X, Y),estado(Z, T), echarC2enC1(X, Y), C1, _) :- (X < C1) , (Y > 0) , (Z is (min(C1, X + Y)) , T is (Y - min( C1, X + Y ) + X)).


/* Encontrar la secuencia de movimientos. Se tiene control de repeticiones para ello vamos almacenando los estados visitados.*/

puede(Estado,Visitados, [],[Estado], _, _, L,0) :- objetivo(Estado, L), nl, write(Visitados).
puede(Estado,Visitados, [Operador|Operadores],[Estado|EstadosCamino], C1, C2, L,Profundidad) :- movimiento(Estado, EstadoSig, Operador, C1 , C2),\+ member(EstadoSig, Visitados),puede(EstadoSig,[EstadoSig|Visitados], Operadores, EstadosCamino, C1, C2, L, Prof), Profundidad is (Prof+1).

/*CONSULTA: */

consulta(C1, C2, L) :-inicial(Estado), puede(Estado,[Estado], Operadores,Estados, C1, C2, L,Profundidad),
nl,write('SOLUCION ENCONTRADA sin repeticion de estados: '), nl, write('OPERADORES: ') ,write(Operadores), nl, write('ESTADOS: '), write(Estados),nl, write('NIVEL DE PROFUNDIDAD: '), write(Profundidad).
