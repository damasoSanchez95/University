/*REPRESENTACION DE ESTADOS DEL PROBLEMA: */

estado(garrafa4L,garrafa3L).

/*Donde garrafa4L y garrafa3L son la cantidad de agua que quedan en las garrafas respectivamente. */

/*ESTADO INICIAL: Asumimos que Inicialmente las garrafas estan vacias, es decir contendrán 0 litros.*/

inicial(estado(0,0)).

/*ESTADO OBJETIVO: El estado objetivo es aquel que tiene exactamente 2 litros de agua en la jarra de 4 litros. No nos importa cuanto hay en la
garrafa de 3L */

objetivo(estado(2,_)).

/*OPERADORES:

 Explicitar las transformaciones de estados mediante un predicado
 movimiento:

	  movimiento(Estado, EstadoSiguiente, Operador)
                         :- Especificacion
*/

/*LLENAR GARRAFA 4L. No nos importa la garrafa de 3L*/
movimiento(estado(X, Y), estado(Z, Y), llenar4(X, Z)) :- (X < 4) , Z is 4.

/*LLENAR GARRAFA 3L. No nos importa la garrafa de 4L*/
movimiento(estado(X, Y), estado(X, Z), llenar3(Y, Z)) :- (Y < 3) , Z is 3.

/*VACIAR GARRAFA 4L*/

movimiento(estado(X, Y), estado(Z, Y), vaciar4(X, Z)) :- (X > 0) , Z is 0.

/*VACIAR GARRAFA 3L*/

movimiento(estado(X, Y), estado(X, Z), vaciar3(Y, Z)) :- (Y > 0) , Z is 0.

/*ECHAR GARRAFA 4L EN 3L*/

movimiento(estado(X, Y), estado(Z, T), echar4en3(X, Y)) :- (X > 0) , (Y < 3) , (Z is (X - min(3, X + Y) + Y) , T is (min( 3, X + Y))).

/*ECHAR GARRAFA 3L EN 4L*/

movimiento(estado(X, Y),estado(Z, T), echar3en4(X, Y)) :- (X < 4) , (Y > 0) , (Z is (min(4, X + Y)) , T is (Y - min( 4, X + Y ) + X)).


/* Encontrar la secuencia de movimientos. Se tiene control de repeticiones para ello vamos almacenando los estados visitados.
HAY QUE ANIADIR EN QUE NIVEL DE PROFUNDIDAD LO ENCONTRAMOS */

puede(Estado,Visitados, [],[Estado]) :- objetivo(Estado), nl, write(Visitados).
puede(Estado,Visitados, [Operador|Operadores],[Estado|EstadosCamino]) :- movimiento(Estado, EstadoSig, Operador),\+ member(EstadoSig, Visitados),puede(EstadoSig,[EstadoSig|Visitados], Operadores, EstadosCamino).

/*CONSULTA: */

consulta :-inicial(Estado), puede(Estado,[Estado], Operadores,Estados),
nl,write('SOLUCION ENCONTRADA sin repeticion de estados: '), nl, write('OPERADORES: ') ,write(Operadores), nl, write('ESTADOS: '), write(Estados). /* write(' NIVEL DE PROFUNDIDAD: '), write(Profundidad).*/
