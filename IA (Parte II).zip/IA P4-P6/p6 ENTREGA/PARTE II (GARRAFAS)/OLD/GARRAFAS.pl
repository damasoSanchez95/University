/*REPRESENTACION DE ESTADOS DEL PROBLEMA: */

estado(garrafa4L,garrafa3L).

/*Donde garrafa4L y garrafa3L son la cantidad de agua que quedan en las garrafas respectivamente. */

*/ESTADO INICIAL: Asumimos que Inicialmente las garrafas estan vacias, es decir contendrán 0 litros.*/

inicial(estado(0,0)).

/*ESTADO OBJETIVO: El estado objetivo es aquel que tiene exactamente 2 litros de agua en la jarra de 4 litros. No nos importa cuanto hay en la 
garrafa de 3L */

objetivo(estado(2,_)).

/*OPERADORES:

 Explicitar las transformaciones de estados mediante un predicado
 movimiento:
      
	  movimiento(Estado, EstadoSiguiente, Operador)
                         :- Especificación

*/

*/LLENAR GARRAFA 4L. No nos importa la garrafa de 3L*/*
movimiento(estado(X, _), estado(Z, _), llenar4(X, Z)) :- (X < 4) , Z is 4 .

/*LLENAR GARRAFA 3L. No nos importa la garrafa de 4L*/*
movimiento(estado(_, Y), estado(_, Z), llenar3(Y, Z)) :- (Y < 3) , Z is 3 .

/*VACIAR GARRAFA 4L*/*

movimiento(estado(X, _), estado(Z, _), vaciar4(X, Z)) :- (X > 0) , Z is 0 .

/*VACIAR GARRAFA 3L*/*

movimiento(estado(_, Y), estado(_, Z), vaciar3(Y, Z)) :- (Y > 0) , Z is 0 .

/*ECHAR GARRAFA 4L EN 3L*/*

movimiento(estado(X, Y), estado(Z, T), echar4en3(X, Y)) :- (X > 0) , (Y < 3) , (Z is (X - min (3, X + Y) + Y) , T is (min ( 3, X + Y)))          .

/*ECHAR GARRAFA 3L EN 4L*/*

movimiento(estado(X,Y),estado(Z,T), echar3en4(X,Y)) :- (X < 4) , (Y > 0) , ( Z is (min ( 4, X + Y)) , T is ( Y - min ( 4, X + Y ) + X))


/**/
/*OPERADORES DE KURSOHHHHH

% Girar el Reloj1 (Solo cuando su parte superior no contienen arena, asi evitamos repeticiones).
movimiento(estado(X,Y), estado(Z,Y), girar1(X,Z)) :- X == 0, Z is 11-X.

% Girar el Reloj2
movimiento(estado(Y,X), estado(Y,Z), girar2(X,Z)) :- X == 0, Z is 7-X.


% Movimiento para dejar caer la arena de los relojes hasta que se quede sin arena el que 
% menos cantidad tenia. Se distinguen los casos en los que R1 > R2, R2 > R1 y R2 = R1.
movimiento(estado(Y,X), estado(0,Z), vaciar1(Y,X)) :- Y < X, Z is X-Y.
movimiento(estado(Y,X), estado(Z,0), vaciar2(Y,X)) :- Y > X, Z is Y-X.
movimiento(estado(X,X), estado(0,0), vaciar3(X,X)).

*/

*/ Encontrar la secuencia de movimientos. Se tiene control de repeticiones para ello vamos almacenando los estados visitados. 
HAY QUE AÑADIR EN QUE NIVEL DE PROFUNDIDAD LO ENCONTRAMOS */

puede(Estado,Visitados, [],[Estado]) :- objetivo(Estado), nl, write(Visitados).
puede(Estado,Visitados, [Operador|Operadores],[Estado|EstadosCamino] ) :- movimiento(Estado, EstadoSig, Operador),\+ member(EstadoSig, Visitados), puede(EstadoSig,[EstadoSig|Visitados], Operadores, EstadosCamino).

/*CONSULTA: */

consulta :-	inicial(Estado), puede(Estado,[Estado], Operadores,Estados),
nl,write('SOLUCION ENCONTRADA sin repeticion de estados: '), nl, write(Operadores), nl, write(Estados).