% REPRESENTACI�N DE ESTADOS DEL PROBLEMA:
% estado(Reloj1,Reloj2)
%   donde Reloj1 y Reloj2 son la cantidad de arena
%   que queda en el cuerpo superior de cada uno de los relojes. Inicialmente
%   contendrán 11 y 7 minutos respectivamente.

% ESTADOS INICIAL Y OBJETIVOS:
inicial(estado(11,7)).

%Hay dos estados objetivos porque puede que la cantidad requerida se obtenga en
%el Reloj1 o en el Reloj2

objetivo(estado(3,_)).
objetivo(estado(_,3)).


% MOVIMIENTOS:

% Girar el Reloj1 (Solo cuando su parte superior no contienen arena, asi evitamos repeticiones).
movimiento(estado(X,Y), estado(Z,Y), girar1(X,Z)) :- X == 0, Z is 11-X.

% Girar el Reloj2
movimiento(estado(Y,X), estado(Y,Z), girar2(X,Z)) :- X == 0, Z is 7-X.


% Movimiento para dejar caer la arena de los relojes hasta que se quede sin arena el que 
% menos cantidad tenia. Se distinguen los casos en los que R1 > R2, R2 > R1 y R2 = R1.
movimiento(estado(Y,X), estado(0,Z), vaciar1(Y,X)) :- Y < X, Z is X-Y.
movimiento(estado(Y,X), estado(Z,0), vaciar2(Y,X)) :- Y > X, Z is Y-X.
movimiento(estado(X,X), estado(0,0), vaciar3(X,X)).



% Encontrar la secuencia de movimientos
puede(Estado,Visitados, [],[Estado]) :- objetivo(Estado), nl, write(Visitados).
puede(Estado,Visitados, [Operador|Operadores],[Estado|EstadosCamino] ) :- movimiento(Estado, Estado2, Operador),\+ member(Estado2, Visitados), puede(Estado2,[Estado2|Visitados], Operadores, EstadosCamino).

% CONSULTA:
consulta :-	inicial(Estado), puede(Estado,[Estado], Operadores,Estados),
nl,write('SOLUCION ENCONTRADA sin repeticion de estados: '), nl, write(Operadores), nl, write(Estados).